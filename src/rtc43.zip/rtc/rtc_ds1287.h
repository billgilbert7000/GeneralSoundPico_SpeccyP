#pragma once
#ifndef _RTC_H_
#define _RTC_H_

#include <stdint.h>
#include <stdbool.h>

extern uint8_t rtc_registr[0x80];
extern uint8_t rtc_adress;
extern bool rtc_adress_data;
extern bool rtc_enable; 

void rtc_ds1287_init(void);
uint8_t rtc_read_registr(uint8_t registr);
void rtc_write_registr(uint8_t adress_reg, uint8_t value);

// Адреса регистров DS1307
#define DS1307_I2C_ADDR   0x68
#define DS1307_SEC_REG    0x00   // Секунды
#define DS1307_MIN_REG    0x01   // Минуты
#define DS1307_HOUR_REG   0x02   // Часы
#define DS1307_DOTW_REG   0x03   // День недели (1-7, 1=воскресенье)
#define DS1307_DATE_REG   0x04   // Число
#define DS1307_MONTH_REG  0x05   // Месяц
#define DS1307_YEAR_REG   0x06   // Год
#define DS1307_CONTROL_REG 0x07  // Control register
#define DS1307_RAM_START  0x08   // Начало пользовательской RAM (56 байт)
#define DS1307_RAM_END    0x3F   // Конец пользовательской RAM

// Адреса регистров DS1287 (эмулируемых)
#define DS1287_SEC        0x00
#define DS1287_ALARM_SEC  0x01
#define DS1287_MIN        0x02
#define DS1287_ALARM_MIN  0x03
#define DS1287_HOUR       0x04
#define DS1287_ALARM_HOUR 0x05
#define DS1287_DOTW       0x06
#define DS1287_DATE       0x07
#define DS1287_MONTH      0x08
#define DS1287_YEAR       0x09
#define DS1287_A          0x0A
#define DS1287_B          0x0B
#define DS1287_C          0x0C
#define DS1287_D          0x0D

#endif