#if defined(RTC_NOVA) || defined(RTC_SMUC)

#include "config.h"  
#include "stdbool.h"
#include "hw_util.h"

#include "hardware/clocks.h"
#include "hardware/pwm.h"
#include "inttypes.h"
#include "hardware/pio.h"
#include <string.h>

#include "hardware/i2c.h"
#include "rtc/rtc_ds1287.h"

/*
   Эмуляция DS1287 с использованием DS1307
   - При ЗАПИСИ в регистры DS1287 - сразу пишем и в DS1307
   - При ЧТЕНИИ - читаем из локального массива (обновляется от системного таймера)
   - DS1307 используется только как хранилище и для начальной установки
*/

// Глобальные переменные
uint8_t rtc_registr[0x80];
uint8_t rtc_adress = 0xff;
bool rtc_adress_data = false;
bool rtc_enable = false;

// Макросы для преобразования BCD
#define bin2bcd(x) ((((x) / 10) << 4) | ((x) % 10))
#define bcd2bin(x) ((((x) >> 4) * 10) + ((x) & 0x0F))

// Массив для хранения времени в BIN формате
uint8_t ds1287_BIN[0x80] = {0};
uint8_t last_hour = 255;
uint64_t system_base_time = 0;

// I2C настройки
#ifndef I2C_RTC_PORT
#define I2C_RTC_PORT i2c1
#endif

#ifndef I2C_RTC_SDA
#define I2C_RTC_SDA 2
#endif

#ifndef I2C_RTC_SCL
#define I2C_RTC_SCL 3
#endif

//=============================================================================
// Инициализация I2C для DS1307
void ds1307_i2c_init(void) {
   
    gpio_set_function(I2C_RTC_SDA, GPIO_FUNC_I2C);
    gpio_set_function(I2C_RTC_SCL, GPIO_FUNC_I2C);
    gpio_pull_up(I2C_RTC_SDA);
    gpio_pull_up(I2C_RTC_SCL);
     i2c_init(I2C_RTC_PORT, 100000);
}

//=============================================================================
// Запись в регистр DS1307
bool write_to_ds1307(uint8_t ds1307_addr, uint8_t value) {
    uint8_t data[2] = {ds1307_addr, value};
    int result = i2c_write_blocking(I2C_RTC_PORT, DS1307_I2C_ADDR, data, 2, false);
    return (result == 2);
}

//=============================================================================
// Чтение из регистра DS1307
bool read_from_ds1307(uint8_t ds1307_addr, uint8_t *value) {
    if (i2c_write_blocking(I2C_RTC_PORT, DS1307_I2C_ADDR, &ds1307_addr, 1, true) != 1)
    {
     gpio_put(LED_PIN, 1);
        return false;
    }
    if (i2c_read_blocking(I2C_RTC_PORT, DS1307_I2C_ADDR, value, 1, false) != 1)
        return false;
gpio_put(LED_PIN, 0);

    return true;
}

//=============================================================================
// Запуск часов DS1307 (сброс бита CH)
bool start_ds1307_clock(void) {
    uint8_t sec_reg;
    if (!read_from_ds1307(DS1307_SEC_REG, &sec_reg))
            {
 //    gpio_put(LED_PIN, 1);
        return false;
    }
    
    sec_reg &= 0x7F;  // Сбрасываем бит CH
    return write_to_ds1307(DS1307_SEC_REG, sec_reg);
}

//=============================================================================
// Сохранение пользовательских регистров в RAM DS1307
void save_user_registers_to_ds1307(void) {
    for (int i = 0; i < 56; i++) {
        uint8_t ds1287_reg = DS1287_A + i;
        uint8_t ds1307_ram_addr = DS1307_RAM_START + i;
        write_to_ds1307(ds1307_ram_addr, ds1287_BIN[ds1287_reg]);
        rtc_registr[ds1287_reg] = ds1287_BIN[ds1287_reg];
    }
}

//=============================================================================
// Загрузка пользовательских регистров из RAM DS1307
void load_user_registers_from_ds1307(void) {
    for (int i = 0; i < 56; i++) {
        uint8_t ds1287_reg = DS1287_A + i;
        uint8_t ds1307_ram_addr = DS1307_RAM_START + i;
        
        uint8_t value;
        if (read_from_ds1307(ds1307_ram_addr, &value)) {
            ds1287_BIN[ds1287_reg] = value;
            rtc_registr[ds1287_reg] = value;
        }
    }
}

//=============================================================================
// Чтение времени из DS1307 и вычисление base_time (только при старте!)
bool read_ds1307_and_calc_base(void) {
    uint8_t reg = 0x00;
    uint8_t time_data[7];
    
    // Запускаем часы если остановлены
     if (read_from_ds1307(DS1307_SEC_REG, &reg) && (reg & 0x80)) {
        start_ds1307_clock();
        sleep_ms(100);
    }  

    if (i2c_write_blocking(I2C_RTC_PORT, DS1307_I2C_ADDR, &reg, 1, true) != 1)
        return false;
    
  if (i2c_read_blocking(I2C_RTC_PORT, DS1307_I2C_ADDR, time_data, 7, false) != 7)
    
       return false;

    // Сохраняем в BIN формате
    ds1287_BIN[DS1287_SEC]   = bcd2bin(time_data[DS1307_SEC_REG] & 0x7F);
    ds1287_BIN[DS1287_MIN]   = bcd2bin(time_data[DS1307_MIN_REG] & 0x7F);
    ds1287_BIN[DS1287_HOUR]  = bcd2bin(time_data[DS1307_HOUR_REG] & 0x3F);
    
    uint8_t dotw = time_data[DS1307_DOTW_REG] & 0x07;
    ds1287_BIN[DS1287_DOTW] = (dotw >= 1 && dotw <= 7) ? (dotw - 1) : 0;
    
    ds1287_BIN[DS1287_DATE]  = bcd2bin(time_data[DS1307_DATE_REG] & 0x3F);
    ds1287_BIN[DS1287_MONTH] = bcd2bin(time_data[DS1307_MONTH_REG] & 0x1F);
    ds1287_BIN[DS1287_YEAR]  = bcd2bin(time_data[DS1307_YEAR_REG]);
    
    // Копируем в rtc_registr
    memcpy(rtc_registr, ds1287_BIN, 10);
    
    // Загружаем пользовательские регистры
    load_user_registers_from_ds1307();
    
    // Вычисляем Unix время для системного таймера
    uint64_t rtc_unix = 0;
    uint16_t year = 2000 + ds1287_BIN[DS1287_YEAR];
    
    static const uint8_t days_in_month[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    for (uint16_t y = 1970; y < year; y++) {
        rtc_unix += ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)) ? 366 : 365;
    }
    
    for (uint8_t m = 1; m < ds1287_BIN[DS1287_MONTH]; m++) {
        rtc_unix += days_in_month[m - 1];
        if (m == 2 && ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))) {
            rtc_unix += 1;
        }
    }
    
    rtc_unix += (ds1287_BIN[DS1287_DATE] - 1);
    rtc_unix = rtc_unix * 86400;
    rtc_unix += ds1287_BIN[DS1287_HOUR] * 3600;
    rtc_unix += ds1287_BIN[DS1287_MIN] * 60;
    rtc_unix += ds1287_BIN[DS1287_SEC];
    
    uint64_t system_time = time_us_64() / 1000000;
    system_base_time = rtc_unix - system_time;
    
    last_hour = ds1287_BIN[DS1287_HOUR];
     
    return true;
}

//=============================================================================
// Обновление времени из системного таймера (НЕ трогаем DS1307!)
void update_time_from_unix(void) {
    uint64_t seconds_total = (time_us_64() / 1000000) + system_base_time;
    
    ds1287_BIN[DS1287_SEC] = seconds_total % 60;
    seconds_total /= 60;
    ds1287_BIN[DS1287_MIN] = seconds_total % 60;
    seconds_total /= 60;
    ds1287_BIN[DS1287_HOUR] = seconds_total % 24;
    
    // Обновляем rtc_registr
    rtc_registr[DS1287_SEC] = ds1287_BIN[DS1287_SEC];
    rtc_registr[DS1287_MIN] = ds1287_BIN[DS1287_MIN];
    rtc_registr[DS1287_HOUR] = ds1287_BIN[DS1287_HOUR];
    
    // При смене суток обновляем дату из DS1307
    if (last_hour == 23 && ds1287_BIN[DS1287_HOUR] == 0) {
        // Читаем только дату из DS1307
        uint8_t reg = 0x00;
        uint8_t time_data[7];
        if (i2c_write_blocking(I2C_RTC_PORT, DS1307_I2C_ADDR, &reg, 1, true) == 1) {
            if (i2c_read_blocking(I2C_RTC_PORT, DS1307_I2C_ADDR, time_data, 7, false) == 7) {
                uint8_t dotw = time_data[DS1307_DOTW_REG] & 0x07;
                ds1287_BIN[DS1287_DOTW] = (dotw >= 1 && dotw <= 7) ? (dotw - 1) : 0;
                ds1287_BIN[DS1287_DATE] = bcd2bin(time_data[DS1307_DATE_REG] & 0x3F);
                ds1287_BIN[DS1287_MONTH] = bcd2bin(time_data[DS1307_MONTH_REG] & 0x1F);
                ds1287_BIN[DS1287_YEAR] = bcd2bin(time_data[DS1307_YEAR_REG]);
                
                rtc_registr[DS1287_DOTW] = ds1287_BIN[DS1287_DOTW];
                rtc_registr[DS1287_DATE] = ds1287_BIN[DS1287_DATE];
                rtc_registr[DS1287_MONTH] = ds1287_BIN[DS1287_MONTH];
                rtc_registr[DS1287_YEAR] = ds1287_BIN[DS1287_YEAR];
            }
        }
    }
    last_hour = ds1287_BIN[DS1287_HOUR];
}

//=============================================================================
// Чтение регистра DS1287
uint8_t rtc_read_registr(uint8_t registr) {
    if (rtc_enable) return 0xFF;
    if (registr > 0x7F) return 0xFF;
    
    // Для регистров времени - обновляем из системного таймера
    if (registr <= DS1287_YEAR) {
        update_time_from_unix();
    }
    
    return ds1287_BIN[registr];
}

//=============================================================================
// ЗАПИСЬ регистра DS1287 (с синхронизацией с DS1307)
void rtc_write_registr(uint8_t adress_reg, uint8_t value) {
    if (rtc_enable) return;
    if (adress_reg > 0x7F) return;
    
    // Сохраняем в локальные массивы
    ds1287_BIN[adress_reg] = value;
    rtc_registr[adress_reg] = value;
    
    // ОДНОВРЕМЕННО пишем в DS1307
    switch (adress_reg) {
        case DS1287_SEC:
            write_to_ds1307(DS1307_SEC_REG, bin2bcd(value) & 0x7F);
            // После записи времени - пересчитываем base_time
            read_ds1307_and_calc_base();
            break;
            
        case DS1287_MIN:
            write_to_ds1307(DS1307_MIN_REG, bin2bcd(value) & 0x7F);
            read_ds1307_and_calc_base();
            break;
            
        case DS1287_HOUR:
            write_to_ds1307(DS1307_HOUR_REG, bin2bcd(value) & 0x3F);
            read_ds1307_and_calc_base();
            break;
            
        case DS1287_DOTW:
            {
                uint8_t ds1307_dotw = (value % 7) + 1;
                write_to_ds1307(DS1307_DOTW_REG, bin2bcd(ds1307_dotw) & 0x07);
            }
            break;
            
        case DS1287_DATE:
            write_to_ds1307(DS1307_DATE_REG, bin2bcd(value) & 0x3F);
            break;
            
        case DS1287_MONTH:
            write_to_ds1307(DS1307_MONTH_REG, bin2bcd(value) & 0x1F);
            break;
            
        case DS1287_YEAR:
            write_to_ds1307(DS1307_YEAR_REG, bin2bcd(value));
            break;
            
        default:
            // Пользовательские регистры - сохраняем в RAM DS1307
            if (adress_reg >= DS1287_A && adress_reg <= (DS1287_A + 55)) {
                uint8_t ds1307_addr = DS1307_RAM_START + (adress_reg - DS1287_A);
                write_to_ds1307(ds1307_addr, value);
            }
            break;
    }
}

//=============================================================================
// Инициализация
void rtc_ds1287_init(void) {
    ds1307_i2c_init();
    sleep_ms(100);
    
    memset(ds1287_BIN, 0, sizeof(ds1287_BIN));
    memset(rtc_registr, 0, sizeof(rtc_registr));
    


    

start_ds1307_clock();

 // gpio_put(LED_PIN, 0);
return;

    // Пытаемся прочитать из DS1307
    if (!read_ds1307_and_calc_base()) {
        // DS1307 не отвечает - устанавливаем время по умолчанию
        rtc_enable = false;
        
        ds1287_BIN[DS1287_SEC] = 0;
        ds1287_BIN[DS1287_MIN] = 0;
        ds1287_BIN[DS1287_HOUR] = 0;
        ds1287_BIN[DS1287_DOTW] = 0;
        ds1287_BIN[DS1287_DATE] = 1;
        ds1287_BIN[DS1287_MONTH] = 1;
        ds1287_BIN[DS1287_YEAR] = 24;
        
        // Записываем в DS1307
        rtc_write_registr(DS1287_SEC, 0);
        rtc_write_registr(DS1287_MIN, 0);
        rtc_write_registr(DS1287_HOUR, 0);
        rtc_write_registr(DS1287_DOTW, 0);
        rtc_write_registr(DS1287_DATE, 1);
        rtc_write_registr(DS1287_MONTH, 1);
        rtc_write_registr(DS1287_YEAR, 24);
        
        // Инициализируем пользовательские регистры
        for (int i = 0; i < 56; i++) {
            ds1287_BIN[DS1287_A + i] = 0;
            rtc_registr[DS1287_A + i] = 0;
        }
        save_user_registers_to_ds1307();
        
        rtc_enable = false;
    } else {
        rtc_enable = true;
    }
    
    update_time_from_unix();
}

//=============================================================================
// Функции для ZX Spectrum
uint8_t rtc_read_data(void) {
    return rtc_read_registr(rtc_adress);
}

void rtc_write_data(uint8_t value) {
    rtc_write_registr(rtc_adress, value);
}

void rtc_set_address(uint8_t addr) {
    rtc_adress = addr;
}

#endif