/**
 * MIT License
 *
 * Copyright (c) 2025 DeepSeek
 
 https://github.com/raspberrypi/pico-sdk/issues/2059

 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */



#include "audio_i2s.h"



/**
 * return the default i2s context used to store information about the setup
 */
i2s_config_t i2s_get_default_config(void) {
    i2s_config_t i2s_config = {
		.sample_freq = I2S_FREQ, 
		.data_pin = AUDIO_DATA_PIN,
		.clock_pin_base = AUDIO_CLOCK_PIN,
        .pio = PIO_I2S, // По умолчанию PIO1, но можно заменить на pio0
		.sm = SM_I2S,
        .dma_i2s = 0,
        .dma_buf = NULL,
        .offset = -1 // Инициализация недопустимым значением
	};

    return i2s_config;
}


 static uint32_t i2s_data;
 static uint32_t trans_count_DMA=1<<30;
 static int dma_i2s;
 void i2s_init(i2s_config_t *i2s_config)
 {


gpio_set_drive_strength(AUDIO_DATA_PIN, GPIO_DRIVE_STRENGTH_8MA); 
gpio_set_drive_strength(AUDIO_DATA_PIN+1, GPIO_DRIVE_STRENGTH_8MA); 
gpio_set_drive_strength(AUDIO_DATA_PIN+2, GPIO_DRIVE_STRENGTH_8MA); 

     // 1. Получаем свободную SM
     i2s_config->sm = SM_I2S;
    // i2s_config->sm = pio_claim_unused_sm(i2s_config->pio, false);
/*      if (i2s_config->sm < 0)
     {
         // Обработка ошибки: нет свободных SM
         gpio_put(25, 1);

         return;
     } */

     // 2. Настройка GPIO
     // Определяем функцию GPIO на основе выбранного PIO
    uint func = (i2s_config->pio == pio0) ? GPIO_FUNC_PIO0 : GPIO_FUNC_PIO1;

     gpio_set_function(i2s_config->data_pin, func);
     gpio_set_function(i2s_config->clock_pin_base, func);
     gpio_set_function(i2s_config->clock_pin_base + 1, func);
     /* Set PIO clock */
     uint32_t system_clock_frequency = clock_get_hz(clk_sys);
     uint32_t divider = system_clock_frequency * 4 / i2s_config->sample_freq; // avoid arithmetic overflow

     // 3. Добавление программы в PIO
     i2s_config->offset = pio_add_program(i2s_config->pio, &audio_i2s_program);
     if (i2s_config->offset < 0) {
         // Обработка ошибки: не удалось добавить программу в PIO
         gpio_put(25, 1);
         return;
     } 
     audio_i2s_program_init(i2s_config->pio, i2s_config->sm, i2s_config->offset, i2s_config->data_pin, i2s_config->clock_pin_base);
     pio_sm_set_clkdiv_int_frac(i2s_config->pio, i2s_config->sm, divider >> 8u, divider & 0xffu);
     pio_sm_set_enabled(i2s_config->pio, i2s_config->sm, false);

     // 4. Настройка DMA
     i2s_config->dma_i2s = dma_claim_unused_channel(true);
     dma_i2s=i2s_config->dma_i2s;
    // i2s_config->dma_i2s_ctrl = dma_claim_unused_channel(true);
     // 5. Конфигурация основного DMA-канала
     dma_channel_config cfg_dma = dma_channel_get_default_config(i2s_config->dma_i2s);
     channel_config_set_transfer_data_size(&cfg_dma, DMA_SIZE_32);
     ///channel_config_set_chain_to(&cfg_dma, i2s_config->dma_i2s_ctrl); // подключение к другому каналу
     channel_config_set_read_increment(&cfg_dma, false);
     channel_config_set_write_increment(&cfg_dma, false);


    // Определяем DREQ для DMA
    uint dreq_base = (i2s_config->pio == pio0) ? DREQ_PIO0_TX0 : DREQ_PIO1_TX0;
    uint dreq = dreq_base + i2s_config->sm;
   //  uint dreq = DREQ_PIO1_TX0 + i2s_config->sm;
     //	if (PIO_I2S==pio0) dreq=DREQ_PIO0_TX0+sm;

     channel_config_set_dreq(&cfg_dma, dreq);

     dma_channel_configure(
         i2s_config->dma_i2s,
         &cfg_dma,
         &i2s_config->pio->txf[i2s_config->sm], // Write address
         &i2s_data,                             // read address
         1024,//(1 << 24),                 // Количество передач (16,777,216 передач)
         true                                  // Запуск сразу
     );
/* 
     // 6. Конфигурация управляющего DMA-канала
     cfg_dma = dma_channel_get_default_config(i2s_config->dma_i2s_ctrl);
     channel_config_set_transfer_data_size(&cfg_dma, DMA_SIZE_32);
     channel_config_set_read_increment(&cfg_dma, false);
     channel_config_set_write_increment(&cfg_dma, false);

     dma_channel_configure(
         i2s_config->dma_i2s_ctrl,// dma канал
         &cfg_dma,//Указатель на структуру конфигурации DMA
         &dma_hw->ch[i2s_config->dma_i2s].al1_transfer_count_trig, // Write address
         // &dma_hw->ch[dma_chan].al2_transfer_count,
         &trans_count_DMA, // read address
         1,                //
         true             // Don't start yet
     ); */
     // 7. Запуск
     pio_sm_set_enabled(i2s_config->pio, i2s_config->sm, true);
     dma_start_channel_mask((1u << i2s_config->dma_i2s));

 }

/// @brief /////////////////////////////////////////////////////////////////////
/// @param i2s_config ////
//  i2s_config_t config = i2s_get_default_config();
//  i2s_init(&config);
// ... использование ...
//  i2s_deinit(&config);
////////////////////////////////////////////////////////////////////////////////
void i2s_deinit(i2s_config_t *i2s_config) {
    // 1. Остановить и освободить оба DMA-канала
    dma_channel_abort(i2s_config->dma_i2s);
    dma_channel_unclaim(i2s_config->dma_i2s);

    // 2. Остановить State Machine PIO
    pio_sm_set_enabled(i2s_config->pio, i2s_config->sm, false);
    
    // 3. Освободить State Machine
    pio_sm_unclaim(i2s_config->pio, i2s_config->sm);
    
    // 4. Удалить программу из PIO
    pio_remove_program(i2s_config->pio, &audio_i2s_program, i2s_config->offset);
    
    // 5. Сбросить GPIO к стандартному режиму
    gpio_set_function(i2s_config->data_pin, GPIO_FUNC_NULL);
    gpio_set_function(i2s_config->clock_pin_base, GPIO_FUNC_NULL);
    gpio_set_function(i2s_config->clock_pin_base + 1, GPIO_FUNC_NULL);
}
/// @brief ////////////////////////////////////////////////////////////////////
/// @param l_out 
/// @param r_out /
void i2s_out(uint16_t left,uint16_t right)
{

    i2s_data=(uint32_t)(left<<16)|(right);

   if (!dma_channel_is_busy(dma_i2s))
    dma_hw->ch[dma_i2s].al1_transfer_count_trig= TRANSFER_COUNT;
    //  dma_hw->ch[dma_i2s].transfer_count=100;
  //   ;
//else    
 //    dma_hw->ch[dma_i2s].al1_transfer_count_trig=(1<<31); 



// Установка количества передач и запуск DMA
//dma_hw->ch[dma_i2s].al1_transfer_count_trig = 1 << 24;
};